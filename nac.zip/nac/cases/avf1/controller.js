(function () {
    'use strict';

    angular.module('wrapper.cases', [])

        .directive('avf1', function () {
            return {
                restrict: 'EA', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'avf1Controller',
                templateUrl: 'scripts/directives/nac/cases/avf1/avf1.html'
            };
        })

        .controller('avf1Controller', [
            '$scope',
            'landingDetails',
            function ($scope, landingDetails) {
                // capture error fields and update navigation json
                var navItem = landingDetails.getNavItem('avf1');
                $scope.$watch('avf1Form.$valid', function (isValid) {
                    navItem.hasError = !isValid;
                });
            }
        ]);
})();