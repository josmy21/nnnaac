(function () {
    'use strict';

    angular.module('wrapper.cases')

        .directive('caseBilling', function () {
            return {
                restrict: 'E', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'caseBillingController', //Define Controller Name
                link: function (scope, elem, attrs) { // jshint ignore:line

                },
                templateUrl: 'scripts/directives/nac/cases/cyberLife/caseBilling/caseBilling.html'
            };
        })

        .controller('caseBillingController', [
            '$scope',
            '$log',
            'appConstantsService',
            function ($scope, $log, appConstantsService) {
                var initialize = function () {
                    $scope.pageDetails = {};
                    $scope.pageDetails.cyberLifeformDd = appConstantsService.getDropdowns().cyberLifeFormType;
                    $scope.pageDetails.cyberLifemodeDd = appConstantsService.getDropdowns().cyberLifeModeType;
                };
                initialize();
            }
        ]);

})();