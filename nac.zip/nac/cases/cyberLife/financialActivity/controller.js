(function () {
    'use strict';

    angular.module('wrapper.cases')

        .directive('financialActivity', function () {
            return {
                restrict: 'E', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'financialActivityController', //Define Controller Name
                link: function (scope, elem, attrs) { // jshint ignore:line

                },
                templateUrl: 'scripts/directives/nac/cases/cyberLife/financialActivity/financialActivity.html'
            };
        })

        .controller('financialActivityController', [
            '$scope',
            '$log',
            function ($scope, $log) {

                var initialize = function () {
                    $scope.pageDetails = {};
                    var finacialData = $scope.taskSummaryData['CyberLife_Financial Activity_financialActivityGrid'].fieldValue;
                    $scope.pageDetails.resultData = finacialData && finacialData !== '' ? JSON.parse(finacialData) : [];

                };
                initialize();
            }
        ]);
})();