(function () {
    'use strict';

    angular.module('wrapper.cases')

        .directive('cyberLife', function () {
            return {
                restrict: 'E', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'cyberLifeController',
                templateUrl: 'scripts/directives/nac/cases/cyberLife/cyberLife.html'
            };
        })
        .controller('cyberLifeController', [
            '$scope',
            '$log',
            'landingDetails',
            function ($scope, $log, landingDetails) {
                // capture error fields and update navigation json
                var navItem = landingDetails.getNavItem('cyberlife');
                $scope.$watch('cyberlifeForm.$valid', function (isValid) {
                    $scope.hasError = navItem.hasError = !isValid;
                });
            }
        ]);
})();