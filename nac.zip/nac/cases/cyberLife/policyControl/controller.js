(function () {
    'use strict';

    angular.module('wrapper.cases')

        .directive('policyControl', function () {
            return {
                restrict: 'E', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'policyControlController', //Define Controller Name
                link: function (scope, elem, attrs) { // jshint ignore:line

                },
                templateUrl: 'scripts/directives/nac/cases/cyberLife/policyControl/policyControl.html'
            };
        })

        .controller('policyControlController', [
            '$scope',
            '$log',
            'appConstantsService',
            function ($scope, $log, appConstantsService) {

                var initialize = function () {
                    $scope.pageDetails = {};
                    $scope.pageDetails.suspendTypeDd = appConstantsService.getDropdowns().cyberLifeSuspendType;
                };
                initialize();
            }
        ]);
})();