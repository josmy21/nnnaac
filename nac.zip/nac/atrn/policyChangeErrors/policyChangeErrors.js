(function () {
    'use strict';

    function policyChangeErrorsController($scope, $log, $state, appConstantsService, $stateParams, $uibModal, $timeout, $rootScope) {
        var initialize = function () {
            $scope.pageDetails ={};
            var gridData = '';
            if ($scope.taskSummaryData.ATRN_Errors_errorGrid) {
                gridData = $scope.taskSummaryData.ATRN_Errors_errorGrid.fieldValue;
            }
            $scope.pageDetails.gridData = gridData && gridData.trim() !== '' ? JSON.parse(gridData) : [];
        };
        initialize();
    }

    angular.module('wrapper.nac')

        .directive('policyChangeErrors', function () {
            return {
                restrict: 'EA', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'policyChangeErrorsController', //Define Controller Name
                link: function (scope, elem, attrs) { // jshint ignore:line

                },
                templateUrl: 'scripts/directives/nac/atrn/policyChangeErrors/policyChangeErrors.html'
            };
        })
        .controller('policyChangeErrorsController', policyChangeErrorsController);

    policyChangeErrorsController.$inject = ['$scope', '$log', '$state', 'appConstantsService', '$stateParams', '$uibModal', '$timeout', '$rootScope'];
})();
