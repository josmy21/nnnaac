(function () {
    'use strict';

    function beneficiaryDetailsController($scope, $log, $state, $uibModal, $confirm, appConstantsService, $stateParams) {

        //--- nac casemanagement beneficiary Details start --//
        $scope.Remove = function (index) {
            $confirm({
                    text: 'Are you sure you want to delete?',
                    title: 'Delete Beneficiary ',
                    ok: 'Yes',
                    cancel: 'No'
                })
                .then(function () {

                    if ($scope.pageDetails.beneficiaryCaseDetails[index].sequenceNo) {
                        $scope.pageDetails.beneficiaryCaseDetails[index].action = 'D';
                    }
                    else {
                        $scope.pageDetails.beneficiaryCaseDetails.splice(index, 1);
                    }

                    $scope.updatebeneficiaryCaseDetails();
                });

        };
        $scope.updatebeneficiaryCaseDetails = function () {
            var field = 'ATRN_Beneficiary Details(ATRN)_beneficiaryGrid';
            var data = [];
            angular.forEach($scope.pageDetails.beneficiaryCaseDetails, function (item) {
                data.push(item);
            });
            if ($scope.taskSummaryData[field]) {
                $scope.taskSummaryData[field].fieldValue = JSON.stringify(data);
            }
        };
        $scope.addCaseBeneficiary = function (index) {
            $scope.beneficiaryCaseDetailscopy = angular.copy($scope.pageDetails.beneficiaryCaseDetails);
            if (!angular.isDefined(index)) {
                $scope.beneficiaryCaseDetailscopy.push($scope.pageDetails.beneGridRow);
                index = $scope.beneficiaryCaseDetailscopy.length - 1;
            }
            var modalInstance = $uibModal.open({
                templateUrl: 'beneficiaryCaseModalContent',
                controller: 'ModalcaseBeneficiaryCtrl',
                windowClass: 'case-modal-window',
                resolve: {
                    items: function () {
                        return angular.copy($scope.beneficiaryCaseDetailscopy);
                    },
                    itemIndex: function () {
                        return index;
                    }
                }
            });
            modalInstance.result.then(function (resultArray) {
                $scope.pageDetails.beneficiaryCaseDetails = resultArray;
                $scope.updatebeneficiaryCaseDetails();
            });
        };

        var initialize = function () {
            $scope.pageDetails = {};
            $scope.pageDetails.beneGridRow = {
                'sequenceNo': null,
                'beneficiaryType': '',
                'prefix': '',
                'firstName': '',
                'middleName': '',
                'lastName': '',
                'suffix': '',
                'gender': '',
                'action': 'N'
            };

            var benCaseData = $scope.taskSummaryData['ATRN_Beneficiary Details(ATRN)_beneficiaryGrid'].fieldValue;
            $scope.pageDetails.beneficiaryCaseDetails = benCaseData && benCaseData.trim() !== '' ? JSON.parse(benCaseData) : [];
            $scope.pageDetails.beneficiaryTypeDropdown = appConstantsService.getDropdowns().beneficiaryType;
            $scope.pageDetails.beneficiaryPrefixDropdown = appConstantsService.getDropdowns().prefix;
            $scope.pageDetails.beneficiarySuffixDropdown = appConstantsService.getDropdowns().suffix;
            $scope.pageDetails.beneficiaryGenderDropdown = appConstantsService.getDropdowns().genderNAC;
            $scope.pageDetails.process = $stateParams.process;
        };
        initialize();
    }

    function ModalcaseBeneficiaryCtrl($scope, $uibModalInstance, items, $log, itemIndex, appConstantsService) {
        $scope.itemIndex = itemIndex;
        $scope.items = items;
        $scope.pageDetails = {};
        $scope.pageDetails.prefixDropdown = appConstantsService.getDropdowns().prefix;
        $scope.pageDetails.suffixDropdown = appConstantsService.getDropdowns().suffix;
        $scope.pageDetails.genderDropdown = appConstantsService.getDropdowns().genderNAC;
        $scope.ok = function () {
            $uibModalInstance.close(items);
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss();
        };
        //To Set the initial Error
        $scope.setForm = function (form) {
            if ($scope.items[itemIndex].action === 'N') {
                form.$$element.attr('no-init-validate', true);
            }
            else {
                form.$$element.removeAttr('no-init-validate');
            }
        };
    }

    angular.module('wrapper.nac')

        .directive('beneficiaryDetails', function () {
            return {
                restrict: 'EA', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'beneficiaryDetailsController', //Define Controller Name
                link: function (scope, elem, attrs) { // jshint ignore:line

                },
                templateUrl: 'scripts/directives/nac/atrn/beneficiaryDetails/beneficiaryDetails.html'
            };
        })
        .controller('beneficiaryDetailsController', beneficiaryDetailsController)
        .controller('ModalcaseBeneficiaryCtrl', ModalcaseBeneficiaryCtrl);

    ModalcaseBeneficiaryCtrl.$inject = ['$scope', '$uibModalInstance', 'items', '$log', 'itemIndex', 'appConstantsService'];

    beneficiaryDetailsController.$inject = ['$scope', '$log', '$state', '$uibModal', '$confirm', 'appConstantsService', '$stateParams'];
})();