'use strict';
describe('Directive: beneficiaryDetails', function () {
    var $compile;
    var $scope, testdata, $state;

    beforeEach(module('wrapper.nac'));
    beforeEach(module('wrapper.Templates'));
    beforeEach(module('ui.router'));
    beforeEach(function () {
        module(function ($provide) {
            $provide.value('$uibModal', {});
            $provide.value('$confirm', {});

            $provide.value('sfgEnvironmentService', {});
            $provide.value('$analytics', {});
            $provide.value('sfgApplication', {
                isMockDataMode: true,
                isAuthenticated: true
            });

            $provide.value('sfgErrorModal', {});

            $provide.value('sfgApplicationLoggingService', {
                debug: function () {}
            });

            $provide.value('sfgEnvironmentService', {
                read: function () {
                    return true;
                }
            });
            $provide.value('appConstantsService', {
                getDropdowns: function () {
                    return [];
                },
                loadConstants: function () {
                    return [];
                }
            });

        });
    });

    beforeEach(inject(function (_$compile_, _$rootScope_, _$state_) {

        $compile = _$compile_;
        $scope = _$rootScope_;
        $state = _$state_;

    }));

    var compiledElement = function (val) {
        var el;
        testdata = readJSON('mock-data/policyDetails_NAC.json');

        var taskSummaryData = {};
        angular.forEach(testdata, function (item) {
            taskSummaryData[item.treePath] = item;
        });
        taskSummaryData.formsStatus = {
            'acwdForm': {
                'pageName': 'ACWD - TIA Money',

                'valid': null
            },
            'atrnForm': {
                'pageName': 'ATRN - Policy Details',

                'valid': null,
                'tabs': {}
            },
            'aprdForm': {
                'pageName': 'APRD - Requirements',

                'valid': null
            }
        };
        $scope.taskSummaryData = taskSummaryData;
        el = angular.element('<beneficiary-details task-summary-data="taskSummaryData"></beneficiary-details>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    describe('getting isolate scope', function () {
        it('binding isolate scope', function () {
            var el = compiledElement();

            expect(el.isolateScope().$id).not.toEqual($scope.$id);

        });

    });
    describe('getting grid', function () {
        it('should load grid', function () {
            var attrName = angular.element(compiledElement()[0].querySelector('table'))[0];
            expect(attrName.rows[1].cells.length).toBe(3);
        });

    });

});