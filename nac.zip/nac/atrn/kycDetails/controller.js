(function () {
    'use strict';

    function kycController($scope, $log, appConstantsService, $uibModal, $confirm, $state, $stateParams) {
        $scope.Remove = function (index) {
            $confirm({
                    text: 'Are you sure you want to delete?',
                    title: 'Delete Child',
                    ok: 'Yes',
                    cancel: 'No'
                })
                .then(function () {
                    $scope.pageDetails.childDetails.splice(index, 1);
                    $scope.updateChildDetails();
                });

        };
        $scope.updateChildDetails = function () {
            //if ($scope.kycForm.$valid) {
            $scope.taskSummaryData['ATRN_KYC Details(ATRN)_ChildInfo_childInfoGrid'].fieldValue = JSON.stringify($scope.pageDetails.childDetails);
            //}
        };

        $scope.open = function (index) {
            $scope.chilDetailscopy = angular.copy($scope.pageDetails.childDetails);
            if (!angular.isDefined(index)) {
                $scope.chilDetailscopy.push({});
                index = $scope.chilDetailscopy.length - 1;
            }
            var modalInstance = $uibModal.open({
                templateUrl: 'childModalContent.html',
                controller: 'ModalChildCtrl',
                resolve: {
                    items: function () {
                        return angular.copy($scope.chilDetailscopy);
                    },
                    itemIndex: function () {
                        return index;
                    }
                }
            });
            modalInstance.result.then(function (resultArray) {
                $scope.pageDetails.childDetails = resultArray;
                $scope.updateChildDetails();
            });
        };
        var initialize = function () {
            $scope.pageDetails = {};
            $scope.pageDetails.plan =false;
            $scope.pageDetails.status = {
                isCustomHeaderOpen: false,
                isFirstOpen: true,
                isFirstDisabled: false
            };
            $scope.pageDetails.process = $stateParams.process;
            $scope.pageDetails.generalheading = 'General Information(Insured)';
            // $scope.pageDetails = 'General Information(Joint Insured)';

            $scope.pageDetails.address = 'Address(Insured)';

            $scope.pageDetails.kycDetailsyesOrNoDropdown = appConstantsService.getDropdowns().yesOrNo;
            $scope.pageDetails.kycDetailsPrefixDropdown = appConstantsService.getDropdowns().prefix;
            $scope.pageDetails.kycDetailsSuffixDropdown = appConstantsService.getDropdowns().suffix;
            $scope.pageDetails.kycDetailsGenderDropdown = appConstantsService.getDropdowns().genderNAC;
            $scope.pageDetails.kycDetailsRatingClass = appConstantsService.getDropdowns().uwClassCode;
            $scope.pageDetails.kycDetailsCountryDropdown = appConstantsService.getCountries();
            $scope.pageDetails.payerDetailsStateDropdown = appConstantsService.getDropdowns().payerDetails;
            $scope.pageDetails.kycDetailsStateDropdown = appConstantsService.getStates();
            var plancode = $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_RLOB'].fieldValue;

            if ($scope.taskSummaryData['ATRN_KYC Details(ATRN)_Owner_owner_type'].fieldValue !== 'Individual') {
                $scope.taskSummaryData['ATRN_KYC Details(ATRN)_Owner_owner_type'].fieldValue = 'Entity';
            }
            if ($scope.taskSummaryData['ATRN_KYC Details(ATRN)_Payor_payor_type'].fieldValue !== 'Individual') {
                $scope.taskSummaryData['ATRN_KYC Details(ATRN)_Payor_payor_type'].fieldValue = 'Entity';
            }
            if (plancode) {
                if (plancode ==='LSG1' || plancode ==='LWG1' || plancode === 'LPG1') {
                    $scope.pageDetails.plan = true;
                }
            }
        };
        initialize();

    }

    function ModalChildCtrl($scope, $uibModalInstance, items, $log, itemIndex, appConstantsService, $stateParams) {
        $scope.itemIndex = itemIndex;
        $scope.items = items;
        $scope.pageDetails = {};
        $scope.pageDetails.kycDetailsGenderDropdown = appConstantsService.getDropdowns().genderGrid;
        $scope.pageDetails.kycDetailsPrefixDropdown = appConstantsService.getDropdowns().prefix;
        $scope.pageDetails.kycDetailsSuffixDropdown = appConstantsService.getDropdowns().suffix;
        $scope.ok = function () {

            $uibModalInstance.close(items);

        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss();
        };
    }

    angular.module('wrapper.nac')

        .directive('kycDetails', function () {
            return {
                restrict: 'E', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'kycController', //Define Controller Name
                link: function (scope, elem, attrs) { // jshint ignore:line

                },
                templateUrl: 'scripts/directives/nac/atrn/kycDetails/kycDetails.html'
            };
        })
        .controller('kycController', kycController)
        .controller('ModalChildCtrl', ModalChildCtrl);

    kycController.$inject = ['$scope', '$log', 'appConstantsService', '$uibModal', '$confirm', '$state', '$stateParams'];
    ModalChildCtrl.$inject = ['$scope', '$uibModalInstance', 'items', '$log', 'itemIndex', 'appConstantsService'];
})();