(function() {
    'use strict';
    /* globals moment: false */
    function additionalDetailsController($scope, $window, $timeout, $log, uibDateParser, $state, $uibModal, $confirm, appConstantsService, $stateParams) {

        $scope.showMasterList = function() {
            var modalInstance = $uibModal.open({
                templateUrl: 'scripts/directives/nac/atrn/additionalDetails/masterCompanyModal.html',
                controller: 'MasterCompanyModalCtrl',
                resolve: {
                    items: function() {
                        return $scope.pageDetails.repInfoGrid;
                    }
                }
            });
            modalInstance.result.then(function(response) {
                if (!!response.resultarray.length) {
                    $scope.pageDetails.repInfoGrid = $scope.pageDetails.repInfoGrid.concat(response.resultarray);
                }
            });
        };
        $scope.addSIC = function() {
            var sicGridRow = {
                'sequenceNo': null,
                'premium_outlay': '',
                'premium_amount': '',
                'action': 'N'
            };
            $scope.pageDetails.sicGrid.push(sicGridRow);
        };

        $scope.addCashWithValue = function() {
            var cashWithValueRow = {
                'sequenceNo': null,
                'informationCode': '',
                'amountOfMoney': '',
                'initialCode': '',
                'date': '',
                'costBasis': '0.00',
                'action': 'N'
            };
            $scope.pageDetails.cashWithValueGrid.push(cashWithValueRow);
        };
        // cash with value remove
        $scope.removeCash = function(index) {
            $confirm({
                    text: 'Are you sure you want to delete?',
                    title: 'Confirm',
                    ok: 'Yes',
                    cancel: 'No'
                })
                .then(function() {
                    if ($scope.pageDetails.cashWithValueGrid[index].sequenceNo) {
                        $scope.pageDetails.cashWithValueGrid[index].action = 'D';
                    }
                    else {
                        $scope.pageDetails.cashWithValueGrid.splice(index, 1);
                    }

                    $scope.updateCashFieldValue();
                });

        };
        $scope.changeRollOver = function() {
            if ($scope.taskSummaryData['ATRN_Additional Details (ATRN)_type_1035Info'].fieldValue === 'Rollover 1035') {
                $scope.taskSummaryData['ATRN_Additional Details (ATRN)_amountType_1035'].fieldValue = '';
            }
        };
        $scope.removeEntry = function(index, grid) {
            var table, entry;
            //Find the record using Index from Array.
            if (grid === 'repInfo') {
                table = 'repInfoGrid';
                entry = $scope.pageDetails[table][index].companyName;
            }
            else {
                table = 'sicGrid';
            }
            entry = 'this entry';
            $confirm({
                text: 'Are you sure you want to delete ' + entry + '?',
                title: 'Confirm',
                ok: 'Yes',
                cancel: 'No'
            }).then(function() {
                //Remove the item from Array using Index.
                if ($scope.pageDetails[table][index].sequenceNo) {
                    $scope.pageDetails[table][index].action = 'D';
                }
                else {
                    $scope.pageDetails[table].splice(index, 1);
                }

                $scope.updateFieldValue(grid, $scope.pageDetails[table]);
            });
        };
        $scope.updateDateFieldValue = function() {
            if ($scope.pageDetails.process !== 'PolicyChange-NA') {
                var isAfter = moment($scope.taskSummaryData['ATRN_Additional Details (ATRN)_applicationDate'].fieldValue).
                isAfter($scope.taskSummaryData['ATRN_Additional Details (ATRN)_applicationReceiveDate'].fieldValue);
                var form = $scope.$parent.$parent.$parent.atrnForm;
                if (isAfter) {
                    $scope.pageDetails.recievedDateError = true;
                    $scope.errorMessage = 'Application Date must be lesser than Application Received Date';
                    form['atrn_additionaldetails(atrn)_applicationdate'].$setValidity('recievedDateError', false);
                }
                else {
                    $scope.pageDetails.recievedDateError = false;
                    $scope.errorMessage = '';
                    form['atrn_additionaldetails(atrn)_applicationdate'].$setValidity('recievedDateError', true);
                }
            }
            else {
                $scope.errorMessage = '';
            }
        };
        $scope.updateFieldValue = function(grid, data) {
            var field = (grid === 'repInfo') ? 'ATRN_Additional Details (ATRN)_replacementInformationGrid' : 'ATRN_Additional Details (ATRN)_salesIllustartionGrid';
            if ($scope.taskSummaryData[field]) {
                $scope.taskSummaryData[field].fieldValue = JSON.stringify(data);
            }
        };
        //Cash with value
        $scope.updateCashFieldValue = function() {
            var field = 'ATRN_Additional Details (ATRN)_CashWithValueGrid';
            if ($scope.taskSummaryData[field]) {
                $scope.taskSummaryData[field].fieldValue = JSON.stringify($scope.pageDetails.cashWithValueGrid);
            }
        };
        //Amendments Details
        $scope.Remove = function(index) {
            $confirm({
                    text: 'Are you sure you want to delete?',
                    title: 'Delete Amendments',
                    ok: 'Yes',
                    cancel: 'No'
                })
                .then(function() {

                    if ($scope.pageDetails.amendmentsDetailsGrid[index].sequenceNo) {
                        $scope.pageDetails.amendmentsDetailsGrid[index].action = 'D';
                    }
                    else {
                        $scope.pageDetails.amendmentsDetailsGrid.splice(index, 1);
                    }

                    $scope.updateAmendmentsDetails();
                });

        };
        //Amendments Details
        $scope.updateAmendmentsDetails = function() {
            $scope.taskSummaryData['ATRN_Additional Details (ATRN)_amendmentsMTVGrid'].fieldValue = JSON.stringify($scope.pageDetails.amendmentsDetailsGrid);
        };

        //Amendments Details
        $scope.openAmendments = function(index) {
            $scope.amendmentsDetailscopy = angular.copy($scope.pageDetails.amendmentsDetailsGrid);
            if (!angular.isDefined(index)) {
                $scope.amendmentsDetailscopy.push($scope.pageDetails.amendmentsDetailsGridRow);
                index = $scope.amendmentsDetailscopy.length - 1;
            }
            var modalInstance = $uibModal.open({
                templateUrl: 'scripts/directives/nac/atrn/additionalDetails/amendmentsMtvModal.html',
                controller: 'ModalAmendmentsCtrl',
                resolve: {
                    items: function() {
                        return angular.copy($scope.amendmentsDetailscopy);
                    },
                    itemIndex: function() {
                        return index;
                    }
                }
            });
            modalInstance.result.then(function(resultArray) {
                $scope.pageDetails.amendmentsDetailsGrid = resultArray;
                $scope.updateAmendmentsDetails();
            });
        };
        //Delivery details
        $scope.openDelivery = function(index) {
            var modalInstance = $uibModal.open({
                templateUrl: 'scripts/directives/nac/atrn/additionalDetails/deliveryChecklist.html',
                controller: 'ModalDeliveryCtrl',
            });
            modalInstance.result.then(function(resultArray) {});
        };
        $scope.validateForm = function() {
            if ($scope.pageDetails.process !== 'PolicyChange-NA') {
                var isAfter = moment($scope.taskSummaryData['ATRN_Additional Details (ATRN)_applicationDate'].fieldValue).
                isAfter($scope.taskSummaryData['ATRN_Additional Details (ATRN)_applicationReceiveDate'].fieldValue);
                var form = $scope.$parent.$parent.$parent.atrnForm;
                if (isAfter) {
                    $scope.pageDetails.recievedDateError = true;
                    $scope.errorMessage = 'Application Date must be lesser than Application Received Date';
                    form['atrn_additionaldetails(atrn)_applicationdate'].$setValidity('recievedDateError', false);
                }
                else {
                    $scope.pageDetails.recievedDateError = false;
                    $scope.errorMessage = '';
                    form['atrn_additionaldetails(atrn)_applicationdate'].$setValidity('recievedDateError', true);
                }
            }
            else {
                $scope.errorMessage = '';
            }
        };
        $scope.updateAmount = function() {
            if ($scope.taskSummaryData['ATRN_Additional Details (ATRN)_type_1035Info'].fieldValue === '') {
                $scope.taskSummaryData['ATRN_Additional Details (ATRN)_amountofMoney_1035'].fieldValue = '';
            }

        };
        var initialize = function() {
            var repInfo = '';
            var sic = '';
            var cashWithValue = '';
            var amendmentsDetails = '';
            $scope.pageDetails = {};
            $scope.pageDetails.sicGridRow = {
                'sequenceNo': null,
                'premium_outlay': '',
                'premium_amount': '',
                'action': 'N'
            };

            $scope.pageDetails.amendmentsDetailsGridRow = {
                'sequenceNo': null,
                'mtvCode': '',
                'printCode': '',
                'person': '',
                'f1': '',
                'f2': '',
                'action': 'N'
            };
            $scope.pageDetails.status = {
                isCustomHeaderOpen: false,
                isFirstOpen: true,
                isFirstDisabled: false
            };
            $timeout(function() {
                $scope.validateForm();
                //console.log($scope.additionalForm)
            }, 100);
            $scope.pageDetails.process = $stateParams.process;
            $scope.pageDetails.additionalStateDropdown = appConstantsService.getStates();
            $scope.pageDetails.yesOrNODropdown = appConstantsService.getDropdowns().yesOrNo;
            $scope.pageDetails.additionalActionDropdown = appConstantsService.getDropdowns().additionalActions;
            $scope.pageDetails.InformationCodeDropdown = appConstantsService.getDropdowns().Informationcode;

            $scope.pageDetails.initialunusual = appConstantsService.getDropdowns().initialUnusual;

            if ($scope.taskSummaryData['ATRN_Additional Details (ATRN)_replacementInformationGrid']) {
                repInfo = $scope.taskSummaryData['ATRN_Additional Details (ATRN)_replacementInformationGrid'].fieldValue;
            }
            $scope.pageDetails.repInfoGrid = repInfo && repInfo.trim() !== '' ? JSON.parse(repInfo) : [];
            if ($scope.taskSummaryData['ATRN_Additional Details (ATRN)_salesIllustartionGrid']) {
                sic = $scope.taskSummaryData['ATRN_Additional Details (ATRN)_salesIllustartionGrid'].fieldValue;
            }
            $scope.pageDetails.sicGrid = sic && sic !== '' ? JSON.parse(sic) : [];
            if ($scope.taskSummaryData['ATRN_Additional Details (ATRN)_CashWithValueGrid']) {
                cashWithValue = $scope.taskSummaryData['ATRN_Additional Details (ATRN)_CashWithValueGrid'].fieldValue;
            }
            $scope.pageDetails.cashWithValueGrid = cashWithValue && cashWithValue !== '' ? JSON.parse(cashWithValue) : [];
            if ($scope.taskSummaryData['ATRN_Additional Details (ATRN)_amendmentsMTVGrid']) {
                amendmentsDetails = $scope.taskSummaryData['ATRN_Additional Details (ATRN)_amendmentsMTVGrid'].fieldValue;
            }
            $scope.pageDetails.amendmentsDetailsGrid = amendmentsDetails && amendmentsDetails !== '' ? JSON.parse(amendmentsDetails) : [];

            $timeout(function() {
                $scope.validateForm();
            }, 100);
        };
        initialize();
    }

    function MasterCompanyModalCtrl($scope, $uibModalInstance, items, appConstantsService, $log) {

        $scope.export = function() {
            var selectedItems = [],
                newRequirement;
            for (var i = 0; i < $scope.pageDetails.masterList.length; i++) {
                if (!$scope.pageDetails.masterList[i].disabled && $scope.pageDetails.masterList[i].selected) {
                    // delete $scope.pageDetails.masterList[i].$$hashKey;
                    // selectedItems.push($scope.pageDetails.masterList[i]);
                    newRequirement = angular.copy($scope.pageDetails.repInfogridRaw);
                    newRequirement.companyName = $scope.pageDetails.masterList[i].companyName;
                    newRequirement.mib = $scope.pageDetails.masterList[i].mib;
                    newRequirement.selected = $scope.pageDetails.masterList[i].selected;
                    selectedItems.push(newRequirement);
                }
            }
            // console.log(selectedItems);
            $uibModalInstance.close({
                resultarray: selectedItems,
            });
        };
        $scope.cancel = function() {
            $uibModalInstance.dismiss();
        };
        $scope.ok = function() {

            $uibModalInstance.close(items);

        };
        $scope.searchFilter = function(renderableRows) {
            var matcher = new RegExp($scope.filterPolicy, 'i');
            renderableRows.forEach(function(row) {
                var match = false;
                if (row.entity.companyName.match(matcher)) {
                    match = true;
                }
                if (!match) {
                    row.visible = false;
                }
            });
            return renderableRows;
        };
        $scope.filterGrid = function() {
            if ($scope.gridApi) {
                $scope.gridApi.grid.refresh();
            }
        };
        $scope.tableHeight = function() {
            var headerHeight = 5;
            // your header height
            return {
                height: $('.ui-grid-render-container').height() + headerHeight + 'px'
            };
        };
        var initialize = function() {
            var masterList = appConstantsService.getCompanyListNAC();
            $scope.pageDetails = {};
            $scope.pageDetails.repInfogridRaw = {
                'sequenceNo': null,
                'exc': '',
                'companyName': '',
                'mib': '',
                'selected': '',
                'replacementAvaliable': '',
                'replacementProcessedDate': '',
                'action': 'N'
            };
            for (var i = 0; i < items.length; i++) {
                for (var j = 0; j < masterList.length; j++) {
                    if (items[i].mib === masterList[j].mib) {
                        masterList[j].disabled = true;
                        masterList[j].selected = true;
                    }
                }
            }
            $scope.pageDetails.masterList = masterList;

            var columnList = [{
                name: 'selected',
                displayName: '',
                type: 'boolean',
                width: 26,
                enableSorting: false,
                cellTemplate: '<input type="checkbox" ng-disabled="row.entity.disabled" ng-model="row.entity.selected">'
            }, {
                field: 'companyName',
                displayName: 'Company Name'
            }, {
                field: 'mib',
                displayName: 'MIB',
                width: 60
            }, {
                field: 'exc',
                displayName: 'Forms Received',
                width: 150
            }];

            $scope.gridOptions = {
                rowHeight: 30,
                headerRowHeight: 30,
                //pagination and sorting
                useExternalSorting: false,
                paginationPageSizes: [10, 25, 50, 100],
                paginationPageSize: 10,
                enableHorizontalScrollbar: 0,
                enableVerticalScrollbar: 1,
                //Data
                data: 'pageDetails.masterList |orderBy:sort.column',
                columnDefs: columnList,
                onRegisterApi: function(gridApi) {
                    $scope.gridApi = gridApi;
                    gridApi.grid.registerRowsProcessor($scope.searchFilter, 200);
                }
            };
        };
        initialize();
    }

    //Amendments Details Modal
    function ModalAmendmentsCtrl($scope, $uibModalInstance, items, $log, itemIndex, appConstantsService, $stateParams) {
        $scope.itemIndex = itemIndex;
        $scope.items = items;
        $scope.pageDetails = {};
        $scope.pageDetails.printCodeDropdown = appConstantsService.getDropdowns().yesOrNo;
        $scope.ok = function() {
            $uibModalInstance.close(items);
        };
        $scope.cancel = function() {
            $uibModalInstance.dismiss();
        };
    }
    //Delivery checklist Modal
    function ModalDeliveryCtrl($scope, $uibModalInstance, $log, $stateParams) {
        $scope.ok = function() {
            $uibModalInstance.close();
        };
        $scope.cancel = function() {
            $uibModalInstance.dismiss();
        };
    }

    angular.module('wrapper.nac')

        .directive('additionalDetails', function() {
            return {
                restrict: 'EA', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'additionalDetailsController',
                templateUrl: 'scripts/directives/nac/atrn/additionalDetails/additionalDetails.html'
            };
        })
        .controller('additionalDetailsController', additionalDetailsController)
        .controller('MasterCompanyModalCtrl', MasterCompanyModalCtrl)
        .controller('ModalAmendmentsCtrl', ModalAmendmentsCtrl)
        .controller('ModalDeliveryCtrl', ModalDeliveryCtrl);

    additionalDetailsController.$inject = ['$scope', '$window', '$timeout', '$log', 'uibDateParser', '$state', '$uibModal', '$confirm', 'appConstantsService', '$stateParams'];
    MasterCompanyModalCtrl.$inject = ['$scope', '$uibModalInstance', 'items', 'appConstantsService', '$log'];
    ModalAmendmentsCtrl.$inject = ['$scope', '$uibModalInstance', 'items', '$log', 'itemIndex', 'appConstantsService'];
    ModalDeliveryCtrl.$inject = ['$scope', '$uibModalInstance', '$log', 'appConstantsService'];
})();