'use strict';
describe('Directive: additional-details', function () {
    var $compile;
    var $scope;
    var $httpBackend, $q, $http, testdata, appConstantsService;
    beforeEach(module('wrapper.nac'));
    beforeEach(module('wrapper.Templates'));
    beforeEach(module('ui.router'));
    beforeEach(module('wrapper.constantsFactory'));
    beforeEach(module('wrapper.services'));
    beforeEach(module('wrapper.environment'));
    beforeEach(module('applicationContextRoot'));
    beforeEach(module('urlUtilities.service'));
    beforeEach(module('applicationContext'));
    beforeEach(module('sfgEnvironment'));
    beforeEach(module('wrapper.model'));

    beforeEach(function () {
        module(function ($provide) {
            $provide.value('$uibModal', {});
            $provide.value('uibDateParser', {});
            $provide.value('$confirm', {});

            $provide.value('sfgEnvironmentService', {});
            $provide.value('$analytics', {});
            $provide.value('sfgApplication', {
                isMockDataMode: true,
                isAuthenticated: true
            });

            $provide.value('sfgErrorModal', {});

            $provide.value('sfgApplicationLoggingService', {
                debug: function () {}
            });

            $provide.value('sfgEnvironmentService', {
                read: function () {
                    return true;
                }
            });
            $provide.value('appConstantsService', {
                getDropdowns: function () {
                    return [];
                },
                loadConstants: function () {
                    return [];
                },
                getStates : function () {
                    return [];
                }
            });
        });
    });

    beforeEach(inject(function (_$compile_, _$rootScope_, _$httpBackend_, _$http_, _$q_, _appConstantsService_, taskService) {

        $compile = _$compile_;
        $scope = _$rootScope_;
        $httpBackend = _$httpBackend_;
        $http = _$http_;
        $q = _$q_;
        appConstantsService = _appConstantsService_;

        $httpBackend.expectGET('data/appConstants.json').respond({});
        $httpBackend.expectGET('data/countries_Cyber.json').respond({});
        $httpBackend.expectGET('data/states.json').respond({});
        $httpBackend.expectGET('/getAllMasterList').respond({});

    }));

    var compiledElement = function (val) {

        var el;
        testdata = readJSON('mock-data/policyDetails_NAC.json');

        var taskSummaryData = {};
        angular.forEach(testdata, function (item) {
            taskSummaryData[item.treePath] = item;
        });
        taskSummaryData.formsStatus = {
            'acwdForm': {
                'pageName': 'ACWD - TIA Money',

                'valid': null
            },
            'atrnForm': {
                'pageName': 'ATRN - Policy Details',

                'valid': null,
                'tabs': {}
            },
            'aprdForm': {
                'pageName': 'APRD - Requirements',

                'valid': null
            }
        };
        $scope.taskSummaryData = taskSummaryData;
        el = angular.element('<additional-details task-summary-data="taskSummaryData"></additional-details>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    describe('getting isolate scope', function () {
        it('binding isolate scope', function () {
            var el = compiledElement();
            expect(el.isolateScope().$id).not.toEqual($scope.$id);

        });

    });
    describe('getting textfields', function () {
        function elementCheck(id, checkval) {
            var attrName = angular.element(angular.element(compiledElement()[0].querySelector('#' + id))[0]).attr('ng-model');
            expect(attrName).toEqual(checkval);

        }
        it('should bind ngmodel', function () {
            elementCheck('ATRN_applicationDate', "taskSummaryData['ATRN_Additional Details (ATRN)_applicationDate'].fieldValue");
            elementCheck('ATRN_applicationReceiveDate', "taskSummaryData['ATRN_Additional Details (ATRN)_applicationReceiveDate'].fieldValue");

        });

    });

});