'use strict';

angular.module('wrapper.nac')

    .directive('coverageDetails', function () {
        return {
            restrict: 'EA',   //Element or Attribute
            scope: {
                taskSummaryData: '=taskSummaryData'
            },
            controller: 'coverageDetailsController', //Define Controller Name
            link: function (scope, elem, attrs) { // jshint ignore:line

            },
            templateUrl: 'scripts/directives/nac/atrn/coverageDetails/coverageDetails.html'
        };
    })

    .controller('coverageDetailsController', [
        '$scope',
        '$log',
        '$state',
        'appConstantsService',
        '$stateParams',
        function ($scope, $log, $state, appConstantsService, $stateParams) {

            var initialize = function () {
                $scope.pageDetails = {};
                $scope.pageDetails.process = $stateParams.process;
                $scope.pageDetails.name = $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_firstname'].fieldValue +' ' +
                $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_middleName'].fieldValue +' ' +
                $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_lastname'].fieldValue;
                $scope.pageDetails.plobDropdown = appConstantsService.getDropdowns().plobCoverage;
                $scope.pageDetails.rlobDropdown =  appConstantsService.getDropdowns().rlob;
                $scope.pageDetails.uwClassCodeDropdown =  appConstantsService.getDropdowns().uwClassCode;
                $scope.pageDetails.commissionOptionDropdown =  appConstantsService.getDropdowns().commissionOption;
                $scope.pageDetails.yesOrNoDropdown  =  appConstantsService.getDropdowns().yesOrNo;
                $scope.pageDetails.spgSvdDropdown  =  appConstantsService.getDropdowns().spaSvg;
                $scope.pageDetails.stateDropdown =  appConstantsService.getStates();
                $scope.pageDetails.paymentTypeDropdown =  appConstantsService.getDropdowns().paymentTypeNAC;
                $scope.pageDetails.billingModeDropdown =  appConstantsService.getDropdowns().billingMode;
                $scope.pageDetails.prefixDropdown =  appConstantsService.getDropdowns().prefix;
                $scope.pageDetails.suffixDropdown =  appConstantsService.getDropdowns().suffix;
                $scope.pageDetails.thirdpartyGenderDropdown = appConstantsService.getDropdowns().genderNAC;
                $scope.pageDetails.bankCaseNumberDropdown =  appConstantsService.getDropdowns().bankCaseNumber;
                $scope.pageDetails.coverageTypeDropdown =  appConstantsService.getDropdowns().coverageType;
                $scope.pageDetails.atrnFormStatus = appConstantsService.getDropdowns().atrnFormStatus;

                $scope.pageDetails.tableRatingOptions = appConstantsService.getDropdowns().tableRatingOptions;
                $scope.pageDetails.permTemFlatOptions = appConstantsService.getDropdowns().permTemFlatOptions;
                $scope.pageDetails.ReasonCodeOptions = appConstantsService.getDropdowns().ReasonCodeOptions;
                $scope.pageDetails.additionalCodeOptions = appConstantsService.getDropdowns().additionalCodeOptions;

                var plancode = $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_RLOB'].fieldValue;
                if (plancode) {
                    if (plancode ==='LSG1' || plancode ==='LWG1' || plancode === 'LPG1') {
                        $scope.pageDetails.survivorship = true;
                    }
                }
                $scope.status = {
                    isCustomHeaderOpen: false,
                    isFirstOpen: true,
                    isFirstDisabled: false
                };
                if ($scope.taskSummaryData['ATRN_KYC Details(ATRN)_Owner_owner_type'].fieldValue !== 'Individual') {
                    $scope.taskSummaryData['ATRN_KYC Details(ATRN)_Owner_owner_type'].fieldValue = 'Entity';
                }

                $scope.onAtrnThirdPartyInfoChange = function() {
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_prefix_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_firstName_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_middleName_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_lastName_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_suffix_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_gender_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_street1_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_street2_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_city_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_state_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_zipcode_ThirdPartyDetails'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_EntityName_ThirdPartyDetailsEntity'].fieldValue = '';
                };

                $scope.onAtrnBankDetailsChange = function() {
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_prefix'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_firstname'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_middleName'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_lastname'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_suffix'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_name'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_bankCaseNumber'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_accountNumber'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_creditCardExpiryDate'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_SVG'].fieldValue = '';
                    $scope.taskSummaryData['ATRN_Coverage Details (ATRN)_firstAndFuture'].fieldValue = '';
                };
            };
            initialize();
        }

        ]);