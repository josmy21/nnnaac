'use strict';

angular.module('wrapper.nac')

    .directive('atrn', function () {
        return {
            restrict: 'EA', //Element or Attribute
            scope: {
                taskSummaryData: '=taskSummaryData'
            },
            controller: 'atrnController', //Define Controller Name
            link: function (scope, elem, attrs) { // jshint ignore:line

            },
            templateUrl: 'scripts/directives/nac/atrn/atrn.html'
        };
    })

    .controller('atrnController', [
        '$scope',
        '$log',
        'landingDetails',
        '$stateParams',
        function ($scope, $log, landingDetails, $stateParams) {
            // capture error fields and update navigation json
            var navItem = landingDetails.getNavItem('atrn');
            $scope.process = $stateParams.process;
            $scope.$watch('atrnForm.$error', function (data) {
                $scope.errorTabs = {};
                if (Object.keys(data).length) {
                    angular.forEach(data, function (obj) {
                        angular.forEach(obj, function (error) {
                            var arr = error.$name.split('_');
                            var page = arr[0];
                            var tab = arr[1];
                            $scope.errorTabs[tab] = true;
                            $log.log('error in field -> ' + error.$name);
                        });
                    });
                    navItem.hasError = true;
                }
                else {
                    navItem.hasError = false;
                }
            }, true);
        }
    ]);