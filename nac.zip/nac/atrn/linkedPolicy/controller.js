'use strict';

angular.module('wrapper.nac')

    .directive('linkedPolicy', function () {
        return {
            restrict: 'EA',
            scope: {
                taskSummaryData: '=taskSummaryData'
            },
            controller: 'linkedPolicyController',
            link: function (scope, elem, attrs) {

            },
            templateUrl: 'scripts/directives/nac/atrn/linkedPolicy/linkedPolicy.html'
        };
    })

    .controller('linkedPolicyController', ['$scope', '$log', '$state', '$rootScope', '$confirm', 'appConstantsService', function ($scope, $log, $state, $rootScope, $confirm, appConstantsService) {
        $scope.removeAgent = function (index) {
            $confirm({
                text: 'Are you sure you want to delete?',
                title: 'Delete Policy',
                ok: 'Yes',
                cancel: 'No'
            }).then(function () {
                //Remove the item from linked policy using Index.
                if ($scope.linkedPolicies[index].sequenceNo) {
                    $scope.linkedPolicies[index].action = 'D';
                }
                else {
                    $scope.linkedPolicies.splice(index, 1);
                }

                $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_linkedPolicyGrid'].fieldValue = JSON.stringify($scope.linkedPolicies);
            });

        };
        $scope.chkDuplicate = function () {
            $scope.pageDetails.lbFound = false;
            if ($scope.newPolicy.policyNumber.length === 10) {
                angular.forEach($scope.linkedPolicies, function (value, key) {
                    if (value.policyNumber === $scope.newPolicy.policyNumber) {
                        $scope.pageDetails.lbFound = true;
                    }
                });
            }
        };

        $scope.addPolicy = function () {
            var linkedPolicies = {
                'sequenceNo': null,
                'policyNumber': '',
                'policyType': '',
                'action': 'N'
            };
            linkedPolicies.policyNumber = $scope.newPolicy.policyNumber;
            linkedPolicies.policyType = $scope.newPolicy.policyType;
            $scope.linkedPolicies.push(linkedPolicies);
            $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_linkedPolicyGrid'].fieldValue = JSON.stringify($scope.linkedPolicies);
            $scope.newPolicy.policyNumber = '';
            $scope.newPolicy.policyType = '';
        };

        var initialize = function () {
            $scope.pageDetails = {};
            $scope.newPolicy = {};
            var reqs = $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_linkedPolicyGrid'].fieldValue;
            $scope.pageDetails.policyTypeDropdown = appConstantsService.getDropdowns().policyType;
            $scope.linkedPolicies = reqs && reqs !== '' ? JSON.parse(reqs) : [];
        };
        initialize();
    }]);

// (function () {
//     'use strict';

//     function linkedPolicyController($scope, $log, $state, $rootScope, $confirm, appConstantsService) {

//         $scope.removeRecord = function (index, grid) {
//             $confirm({
//                     text: 'Are you sure you want to delete?',
//                     title: 'Delete Policy',
//                     ok: 'Yes',
//                     cancel: 'No'
//                 }).then(function () {

//                     if (grid === 'lifeComPolicyGrid') {
//                         if ($scope.pageDetails.lifeComPolicyGrid[index].sequenceNo) {
//                             $scope.pageDetails.lifeComPolicyGrid[index].action = 'D';
//                         }

//                         else {
//                             $scope.pageDetails.lifeComPolicyGrid.splice(index, 1);
//                         }
//                         $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_lifeComPolicyGrid'].fieldValue = JSON.stringify($scope.pageDetails.lifeComPolicyGrid);
//                     }

//                     if (grid === 'policyNumberGrid') {
//                         if ($scope.pageDetails.policyNumberGrid[index].sequenceNo) {
//                             $scope.pageDetails.policyNumberGrid[index].action = 'D';
//                         }

//                         else {
//                             $scope.pageDetails.policyNumberGrid.splice(index, 1);
//                         }
//                         $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_policyNumberGrid'].fieldValue = JSON.stringify($scope.pageDetails.policyNumberGrid);
//                     }

//                 });

//         };

//         $scope.addNewRecord = function (grid) {

//             if (grid === 'lifeComPolicyGrid') {

//                 // var lifeComm =[];

//                 var lifeComm = {
//                 'sequenceNo':null,
//                 'lifecommPolicyNumber':'',
//                 'description':'',
//                 'Comments':'',
//                 'robotAction':'',
//                 'action':'N'

//             };
//                 $scope.pageDetails.lifeComPolicyGrid.push(lifeComm);
//                 $scope.updateGrid(grid);
//                 $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_lifeComPolicyGrid'].fieldValue = JSON.stringify($scope.pageDetails.lifeComPolicyGrid);

//             }

//             if (grid === 'policyNumberGrid') {
//                 var linkedPolicies = {
//                     'sequenceNo':null,
//                     'policyNumber':'',
//                     'trailerPolicyNumber':'',
//                     'policyType':'',
//                     'robotaction':'',
//                     'action':'N'
//                 };
//                 // var linkedPolicies=[];
//                 $scope.pageDetails.policyNumberGrid.push(linkedPolicies);
//                 $scope.updateGrid(grid);
//                 $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_policyNumberGrid'].fieldValue = JSON.stringify($scope.pageDetails.policyNumberGrid);
//             }

//         };
//         $scope.updateGrid = function(grid) {

//             if (grid === 'lifeComPolicyGrid') {
//                 $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_lifeComPolicyGrid'].fieldValue = JSON.stringify($scope.pageDetails.lifeComPolicyGrid);
//             }
//             if (grid === 'policyNumberGrid') {
//                 $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_policyNumberGrid'].fieldValue = JSON.stringify($scope.pageDetails.policyNumberGrid);
//             }

//         };

//         var initialize = function () {
//             $scope.pageDetails = {};
//             $scope.newPolicy = {};
//             $scope.pageDetails.policyTypeDropdown = appConstantsService.getDropdowns().policyTypeAppentry;
//

//             var reqs2 = $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_lifeComPolicyGrid'].fieldValue;
//             $scope.pageDetails.lifeComPolicyGrid = reqs2 && reqs2 !== '' ? JSON.parse(reqs2) : [];

//             var reqs1 = $scope.taskSummaryData['ATRN_Linked_Policy(ATRN)_policyNumberGrid'].fieldValue;
//             $scope.pageDetails.policyNumberGrid = reqs1 && reqs1 !== '' ? JSON.parse(reqs1) : [];

//         };
//         initialize();
//     }

//     angular.module('wrapper.nac')

//         .directive('linkedPolicy', function () {
//             return {
//                 restrict: 'EA', //Element or Attribute
//                 scope: {
//                     taskSummaryData: '=taskSummaryData'
//                 },
//                 controller: 'linkedPolicyController', //Define Controller Name
//                 link: function (scope, elem, attrs) { // jshint ignore:line

//                 },
//                 templateUrl: 'scripts/directives/nac/atrn/linkedPolicy/linkedPolicy.html'
//             };
//         })
//         .controller('linkedPolicyController', linkedPolicyController);
//     linkedPolicyController.$inject = ['$scope', '$log', '$state', '$rootScope', '$confirm', 'appConstantsService'];
// })();
