(function () {
    'use strict';

    function riderDetailsController($scope, $log, $state, $rootScope, appConstantsService, $uibModal, $confirm, $stateParams) {
        $scope.Remove = function (index) {
            $confirm({
                    text: 'Are you sure you want to delete?',
                    title: 'Delete Child',
                    ok: 'Yes',
                    cancel: 'No'
                })
                .then(function () {

                    if ($scope.pageDetails.childDetails[index].sequenceNo) {
                        $scope.pageDetails.childDetails[index].action = 'D';
                    }
                    else {
                        $scope.pageDetails.childDetails.splice(index, 1);
                    }

                    $scope.updateChildDetails();
                });
        };
        $scope.updateChildDetails = function () {
            $scope.taskSummaryData['ATRN_Rider Details (ATRN)_ChildRiderInformationGrid'].fieldValue = JSON.stringify($scope.pageDetails.childDetails);
        };
        $scope.open = function (index) {
            $scope.chilDetailscopy = angular.copy($scope.pageDetails.childDetails);
            if (!angular.isDefined(index)) {
                $scope.chilDetailscopy.push($scope.pageDetails.riderChildRow);
                index = $scope.chilDetailscopy.length - 1;
            }
            var modalInstance = $uibModal.open({
                templateUrl: 'childRiderModalContent',
                controller: 'ModalRiderChildCtrl',
                windowClass: 'app-modal-window',
                resolve: {
                    items: function () {
                        return angular.copy($scope.chilDetailscopy);
                    },
                    itemIndex: function () {
                        return index;
                    }
                }
            });
            modalInstance.result.then(function (resultArray) {
                $scope.pageDetails.childDetails = resultArray;
                $scope.updateChildDetails();
            });
        };
        var initialize = function () {
            $scope.pageDetails = {};
            $scope.pageDetails.status = {
                isCustomHeaderOpen: false,
                isFirstOpen: true,
                isFirstDisabled: false
            };
            $scope.pageDetails.riderChildRow = {
                'sequenceNo':null,
                'firstName':'',
                'middleName':'',
                'lastName':'',
                'suffix':'',
                'gender':'',
                'prefix':'',
                'dob':'',
                'age':'',
                'ssn':'',
                'action':'N'
            };
            $scope.pageDetails.plobDropdown = appConstantsService.getDropdowns().plob;
            $scope.pageDetails.planCodeDropdown = appConstantsService.getDropdowns().mortalityClassCode;
            $scope.pageDetails.yesOrNoDropdown = appConstantsService.getDropdowns().yesOrNo;
            $scope.pageDetails.waiverDropdown = appConstantsService.getDropdowns().optionYesorNoBlank;
            $scope.pageDetails.prefixDropdown = appConstantsService.getDropdowns().prefix;
            $scope.pageDetails.suffixDropdown = appConstantsService.getDropdowns().suffix;
            $scope.pageDetails.genderDropdown = appConstantsService.getDropdowns().genderNAC;
            $scope.pageDetails.monthlyDeductiondropdown = appConstantsService.getDropdowns().monthlyDeduction1;
            $scope.pageDetails.accidentalDeathBenefitdropdown1 = appConstantsService.getDropdowns().accidentalDeathBenefit1;
            $scope.pageDetails.process = $stateParams.process;
            var reqs = $scope.taskSummaryData['ATRN_Rider Details (ATRN)_ChildRiderInformationGrid'].fieldValue;
            $scope.pageDetails.childDetails = reqs && reqs.trim() !== '' ? JSON.parse(reqs) : [];
        };
        initialize();
    }

    function ModalRiderChildCtrl($scope, $uibModalInstance, items, $log, itemIndex, appConstantsService) {
        $scope.itemIndex = itemIndex;
        $scope.items = items;
        $scope.pageDetails = {};
        $scope.pageDetails.prefixDropdown = appConstantsService.getDropdowns().prefix;
        $scope.pageDetails.suffixDropdown = appConstantsService.getDropdowns().suffix;
        $scope.pageDetails.genderDropdown = appConstantsService.getDropdowns().genderNAC;
        $scope.ok = function () {
            $uibModalInstance.close(items);
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss();
        };
        //To Set the initial Error
        $scope.setForm = function (form) {
            if ($scope.items[itemIndex].action === 'N') {
                form.$$element.attr('no-init-validate', true);
            }
            else {
                form.$$element.removeAttr('no-init-validate');
            }
        };
    }

    angular.module('wrapper.nac')
        .directive('riderDetails', function () {
            return {
                restrict: 'EA',
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'riderDetailsController',
                link: function (scope, elem, attrs) {},
                templateUrl: 'scripts/directives/nac/atrn/riderDetails/riderDetails.html'
            };
        })
        .controller('riderDetailsController', riderDetailsController)
        .controller('ModalRiderChildCtrl', ModalRiderChildCtrl);

    riderDetailsController.$inject = ['$scope', '$log', '$state', '$rootScope', 'appConstantsService', '$uibModal', '$confirm', '$stateParams'];
    ModalRiderChildCtrl.$inject = ['$scope', '$uibModalInstance', 'items', '$log', 'itemIndex', 'appConstantsService'];

}());