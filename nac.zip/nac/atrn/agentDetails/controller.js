(function() {
    'use strict';

    angular.module('wrapper.nac')

        .directive('agentDetails', function() {
            return {
                restrict: 'EA', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'agentDetailsController', //Define Controller Name
                link: function(scope, elem, attrs) { // jshint ignore:line
                },
                templateUrl: 'scripts/directives/nac/atrn/agentDetails/agentDetails.html'
            };
        })

        .controller('agentDetailsController', ['$scope', '$window', '$log', '$state', '$confirm', 'appConstantsService', '$stateParams',
            function($scope, $window, $log, $state, $confirm, appConstantsService, $stateParams) {
                $scope.Add = function() {
                    //Add the new item to the Array.
                    var splitNew = {'sequenceNo':null, 'agentNumber':'', 'agentPercentage':'', 'situationCode':'', 'action':'N'};
                    $scope.pageDetails.splitAgentValues.push(splitNew);
                };
                $scope.removeAgent = function(index) {
                    //Find the record using Index from Array.
                    //Remove the item from Array using Index.

                    $confirm({
                            text: 'Are you sure you want to delete?',
                            title: 'Delete Split',
                            ok: 'Yes',
                            cancel: 'No'
                        })
                        .then(function() {
                            if ($scope.pageDetails.splitAgentValues[index].sequenceNo) {
                                $scope.pageDetails.splitAgentValues[index].action = 'D';
                            }
                            else {
                                $scope.pageDetails.splitAgentValues.splice(index, 1);
                            }

                            $scope.updateSplitAgentgrid();
                        });
                };
                $scope.updateAgentDetails = function () {

                    if ($scope.taskSummaryData['ATRN_Agent Details (ATRN)_agentSplit'].fieldValue === 'N' && $scope.pageDetails.splitAgentValues.length >0) {
                        $confirm({
                            text: 'Are you sure you want to delete the Split Agent details?',
                            title: 'Delete Split',
                            ok: 'Yes',
                            cancel: 'No'
                        })
                        .then(function() {
                            $scope.pageDetails.splitAgentValues = [];
                            $scope.taskSummaryData['ATRN_Agent Details (ATRN)_splitAgentGrid'].fieldValue = '';
                            $scope.updateSplitAgentgrid();
                        }, function () {
                            $scope.taskSummaryData['ATRN_Agent Details (ATRN)_agentSplit'].fieldValue = 'Y';
                        });
                    }
                    if ($scope.taskSummaryData['ATRN_Agent Details (ATRN)_agentSplit'].fieldValue === 'Y') {
                        $scope.updateSplitAgent();
                    }
                };
                var initialize = function() {
                    $scope.pageDetails = {};
                    var reqs = $scope.taskSummaryData['ATRN_Agent Details (ATRN)_splitAgentGrid'].fieldValue;
                    $scope.pageDetails.splitAgentValues = reqs && reqs !== '' ? JSON.parse(reqs) : [];
                    var agentError = $scope.taskSummaryData['ATRN_Agent Details (ATRN)_agentLicensingErrorGrid'].fieldValue;
                    $scope.pageDetails.splitAgenterrorCodes = agentError && agentError !== '' ? JSON.parse(agentError) : [];
                    $scope.pageDetails.agentDetailsyesOrNoDropdown = appConstantsService.getDropdowns().yesOrNo;
                    $scope.pageDetails.agentDetailsmarketCodeDropdown = appConstantsService.getDropdowns().marketCode;
                    $scope.pageDetails.process = $stateParams.process;
                    $scope.updateSplitAgent();

                };
                $scope.updateSplitAgentgrid = function () {
                    if ($scope.taskSummaryData['ATRN_Agent Details (ATRN)_splitAgentGrid']) {
                        $scope.taskSummaryData['ATRN_Agent Details (ATRN)_splitAgentGrid'].fieldValue = JSON.stringify($scope.pageDetails.splitAgentValues);
                    }
                };
                $scope.updateSplitAgent = function() {
                    //console.log($scope.pageDetails.writingPercentage);
                    if ($scope.taskSummaryData['ATRN_Agent Details (ATRN)_agentPercentage_WritingAgent'].fieldValue === '') {
                        $scope.taskSummaryData['ATRN_Agent Details (ATRN)_agentPercentage_WritingAgent'].fieldValue = 0;
                    }
                    $scope.pageDetails.writingPercentage = parseFloat($scope.taskSummaryData['ATRN_Agent Details (ATRN)_agentPercentage_WritingAgent'].fieldValue);

                    $scope.pageDetails.totalValue = 0;
                    for (var i = 0; i < $scope.pageDetails.splitAgentValues.length; i++) {
                        if ($scope.pageDetails.splitAgentValues[i].agentPercentage === '') {
                            $scope.pageDetails.splitAgentValues[i].agentPercentage =0;
                        }
                        if ($scope.pageDetails.splitAgentValues[i].action !== 'D') {
                            $scope.pageDetails.totalValue +=  parseFloat($scope.pageDetails.splitAgentValues[i].agentPercentage);

                        }
                    }
                    $scope.pageDetails.totalValue += $scope.pageDetails.writingPercentage;
                    var form = $scope.$parent.atrnForm;
                    if (form['atrn_agentdetails(atrn)_agentpercentage_writingagent']) {
                        if ( $scope.pageDetails.totalValue !== 100)
                            {
                            $scope.pageDetails.percentageError = true;
                            $scope.errorMessage = 'Make sure the total Agent percentage value is always 100';

                            form['atrn_agentdetails(atrn)_agentpercentage_writingagent'].$setValidity('percentageError', false);

                        }
                        else {

                            $scope.pageDetails.percentageError = false;
                            $scope.errorMessage = '';

                            form['atrn_agentdetails(atrn)_agentpercentage_writingagent'].$setValidity('percentageError', true);
                        }
                    }
                    $scope.updateSplitAgentgrid();
                };
                initialize();
            }
        ]);
}());