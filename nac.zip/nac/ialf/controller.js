'use strict';

angular.module('wrapper.nac')

    .directive('ialf', function () {
        return {
            restrict: 'EA',   //Element or Attribute
            scope: {
                taskSummaryData: '=taskSummaryData'
            },
            controller: 'ialfController',
            templateUrl: 'scripts/directives/nac/ialf/ialf.html'
        };
    })

    .controller('ialfController', [
        '$scope',
        '$log',
        'landingDetails',
        function ($scope, $log, landingDetails) {
            // update navigation json to show no validation error
            var navItem = landingDetails.getNavItem('ialf');
            navItem.hasError = false;

            var initialize = function() {
                    var gridData = '';
                    $scope.pageDetails = {};
                    if ($scope.taskSummaryData.IALF_IALFGrid) {
                        gridData = $scope.taskSummaryData.IALF_IALFGrid.fieldValue;
                    }
                    $scope.pageDetails.resultData = gridData && gridData.trim() !== '' ? JSON.parse(gridData) : [];
                };
            initialize();
        }]);