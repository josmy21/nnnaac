'use strict';
describe('Directive: ialf', function () {
    var $compile;
    var $scope;

    beforeEach(module('wrapper.nac'));
    beforeEach(module('wrapper.Templates'));

    beforeEach(inject(function (_$compile_, _$rootScope_) {

        $compile = _$compile_;
        $scope = _$rootScope_;

    }));
    var compiledElement = function (val) {
        var el;
        $scope.tests = val;
        $scope.taskSummaryData = {
            'IALF_IALFGrid': {
                'transactionId': 3,
                'taskName': 'NAC App Assessment',
                'sectionId': 37,
                'treePath': 'IALF_IALFGrid',
                'fieldName': 'IALFGrid',
                'fieldValue': '[{"id": "1","name": "Todd/Chris/Mark","companyCode": "100","policyNumber": "LB0618396",' +
                '"sex": "IOP","stb": "I","dateOfBirth":"11/20/1997","identificationNumber":"217-50-3245","lastName":"Mark","firstName":"Smith","middleName": "Roger"}]',
                'fieldValuesId': 421,
                'fieldId': 695,
                'assignedTo': 'test',
                'validation': 'All'
            },
            'formstatus': {
                'acwdForm': {
                    'pageName': 'ACWD - TIA Money',
                    'stateName': 'taskDetail.acwd',
                    'valid': null
                },
                'atrnForm': {
                    'pageName': 'ATRN - Policy Details',
                    'stateName': 'taskDetail.atrn',
                    'valid': null,
                    'tabs': {}
                },
                'aprdForm': {
                    'pageName': 'APRD - Requirements',
                    'stateName': 'taskDetail.aprd',
                    'valid': null
                }
            }
        };
        el = angular.element('<ialf task-summary-data="taskSummaryData"></ialf>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    describe('getting isolate scope', function () {
        it('binding isolate scope', function () {
            var el = compiledElement().isolateScope();
            el.taskSummaryData.IALF_IALFGrid.transactionId = 5;
            expect($scope.taskSummaryData.IALF_IALFGrid.transactionId).toEqual(3);

        });

    });
    describe('getting grid', function () {
        it('should load grid', function () {
            var attrName = angular.element(compiledElement()[0].querySelector('table'))[0];
            expect(attrName.rows[1].cells.length).toBe(8);

        });

    });

});