'use strict';

angular.module('wrapper.nac')

    .directive('bcfdScreen', function () {
        return {
            restrict: 'E',   //Element or Attribute
            scope: {
                taskSummaryData: '=taskSummaryData'
            },
            controller: 'bcfdScreenController', //Define Controller Name
            link: function (scope, elem, attrs) { // jshint ignore:line

            },
            templateUrl: 'scripts/directives/nac/bcfd/bcfd.html'
        };
    })

    .controller('bcfdScreenController', [
        '$scope',
        '$log',
        '$state',
        '$location',
        'appConstantsService',
        function ($scope, $log, $state, $location, appConstantsService) {

            //Common function to track the form validations
            $scope.$watch('bcfdForm.$valid', function(isValid) {
                $scope.taskSummaryData.formsStatus.atrnForm.tabs.bcfdForm = {
                    pageName: 'BCFD',
                    stateUrl: $state.current.url,
                    valid: isValid
                };
            });

            var initialize = function () {
                $scope.pageDetails = {};
                $scope.pageDetails.bcfdActionDropdown =  appConstantsService.getDropdowns().bcfdAction;
                $scope.pageDetails.bcfdTypeDropdown =  appConstantsService.getDropdowns().bcfdType;
                $scope.pageDetails.bcfdCaseNumberDropdown =  appConstantsService.getDropdowns().bcfdCaseNumber;
                $scope.pageDetails.yesOrNoDropdown =  appConstantsService.getDropdowns().yesOrNo;
            };
            initialize();
        }]);

