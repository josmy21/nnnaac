'use strict';

angular.module('wrapper.nac')

    .directive('replScreen', function () {
        return {
            restrict: 'E',   //Element or Attribute
            scope: {},
            controller: 'replScreenController', //Define Controller Name
            link: function (scope, elem, attrs) { // jshint ignore:line

            },
            templateUrl: 'scripts/directives/nac/repl/repl.html'
        };
    })

    .controller('replScreenController', [
        '$scope',
        '$log',
        '$rootScope',
        '$location',

        function ($scope, $log, $rootScope, $location) {

            $log.info('replScreenController');

            $scope.taskData = {
                'replScreen' :

                    {'replScreendetails':
                        [{
                            'selectCompany': 'yes',
                            'exc': 'test',
                            'companyName': 'test',
                            'mib': 'test',
                            'formsReceived': 'test'
                        },
                        {
                            'selectCompany': 'yes',
                            'exc': 'test',
                            'companyName': 'test',
                            'mib': 'test',
                            'formsReceived': 'test'
                        },
                        {
                            'selectCompany': 'yes',
                            'exc': 'test',
                            'companyName': 'test',
                            'mib': 'test',
                            'formsReceived': 'test'
                        },
                        {
                            'selectCompany': 'yes',
                            'exc': 'test',
                            'companyName': 'test',
                            'mib': 'test',
                            'formsReceived': 'test'
                        },
                        {
                            'selectCompany': 'yes',
                            'exc': 'test',
                            'companyName': 'test',
                            'mib': 'test',
                            'formsReceived': 'test'
                        }
                        ]
                    }

            };

        }]);

