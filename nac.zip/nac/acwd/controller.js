'use strict';
angular.module('wrapper.nac')
    .directive('acwd', function () {
        return {
            restrict: 'EA',
            scope: {
                taskSummaryData: '=taskSummaryData'
            },
            controller: 'acwdController',
            link: function (scope, elem, attrs) {

            },
            templateUrl: 'scripts/directives/nac/acwd/acwd.html'
        };
    })
    .controller('acwdController', [
        '$scope',
        '$log',
        '$state',
        '$confirm',
        'appConstantsService',
        'landingDetails',
        function ($scope, $log, $state, $confirm, appConstantsService, landingDetails) {
            // capture error fields and update navigation json
            var navItem = landingDetails.getNavItem('acwd');
            $scope.$watch('acwdForm.$valid', function (isValid) {
                navItem.hasError = !isValid;
            });
            $scope.addMoney = function() {
                $scope.pageDetails.acwdGridRow ={
                    'sequenceNo':null,
                    'transactionCode':'',
                    'caseAmount':'',
                    'SQNM' : '',
                    'action':'N'
                };
                $scope.pageDetails.acwdGrid.push($scope.pageDetails.acwdGridRow);
            };
            $scope.updateMoney = function () {
                $scope.taskSummaryData.ACWD_acwdGrid.fieldValue = JSON.stringify($scope.pageDetails.acwdGrid);
            };
            var initialize = function () {
                $scope.pageDetails = {};
                var acwd = '';
                $scope.pageDetails.acwdGridRow ={
                    'sequenceNo':null,
                    'transactionCode':'',
                    'caseAmount':'',
                    'SQNM' : '',
                    'action':'N'
                };
                $scope.pageDetails.transCodeDropdown = appConstantsService.getDropdowns().transactionCode;
                if ($scope.taskSummaryData.ACWD_acwdGrid) {
                    acwd = $scope.taskSummaryData.ACWD_acwdGrid.fieldValue;
                }
                $scope.pageDetails.acwdGrid = acwd && acwd !== '' ? JSON.parse(acwd) : [];
            };
            initialize();
        }
    ]);

    /*"[{\"sequenceNo\":null,
    \"errorCode\":\"WNOO\",
    \"description\":\"AML has expired or Non-Existant\",
    \"action\":\"\"}]*/