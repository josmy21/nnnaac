'use strict';
describe('Directive: aaxd', function () {
    var $compile;
    var $scope;

    beforeEach(module('wrapper.nac'));
    beforeEach(module('wrapper.Templates'));

    beforeEach(inject(function (_$compile_, _$rootScope_) {

        $compile = _$compile_;
        $scope = _$rootScope_;

    }));
    var compiledElement = function (val) {
        var el;
        $scope.tests = val;
        $scope.taskSummaryData = {
            'AAXD_duplicateSearchGrid': {
                'transactionId': 3,
                'taskName': 'NAC App Assessment',
                'sectionId': 36,
                'treePath': 'AAXD_duplicateSearchGrid',
                'fieldName': 'duplicateSearchGrid',
                'fieldValue': '[{"id":"1","name":"Todd/Chris/Mark","companyCode":"100",' +
                 ' "policyNumber":"LB0618396","relationship":"IOP","type":"I",' +
                 '"writingAgencyCode":"G9444","dateOfBirth":"11/20/1997","lastName":"Mark",' +
                 '"firstName":"Smith","middleName":"Roger"}]',
                'fieldValuesId': 420,
                'fieldId': 694,
                'assignedTo': 'test',
                'validation': 'All'
            },
            'formsStatus': {
                'acwdForm': {
                    'pageName': 'ACWD - TIA Money',
                    'stateName': 'taskDetail.acwd',
                    'valid': null
                },
                'atrnForm': {
                    'pageName': 'ATRN - Policy Details',
                    'stateName': 'taskDetail.atrn',
                    'valid': null,
                    'tabs': {}
                },
                'aprdForm': {
                    'pageName': 'APRD - Requirements',
                    'stateName': 'taskDetail.aprd',
                    'valid': null
                }
            }
        };
        el = angular.element('<aaxd task-summary-data="taskSummaryData"></aaxd>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    describe('getting isolate scope', function () {
        it('binding isolate scope', function () {
            var el = compiledElement().isolateScope();
            el.taskSummaryData.AAXD_duplicateSearchGrid.transactionId = 5;
            expect($scope.taskSummaryData.AAXD_duplicateSearchGrid.transactionId).toEqual(5);

        });

    });
    describe('getting grid', function () {
        it('should load grid', function () {
            var attrName = angular.element(compiledElement()[0].querySelector('table'))[0];
            expect(attrName.rows[1].cells.length).toBe(7);

        });

    });

});