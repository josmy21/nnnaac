(function () {
    'use strict';

    angular.module('wrapper.nac', [])

        .directive('aaxd', function () {
            return {
                restrict: 'EA', //Element or Attribute
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'aaxdController',
                templateUrl: 'scripts/directives/nac/aaxd/aaxd.html'
            };
        })

        .controller('aaxdController', [
            '$scope',
            '$log',
            'landingDetails',
            function ($scope, $log, landingDetails) {
                // update navigation json to show no validation error
                var navItem = landingDetails.getNavItem('aaxd');
                navItem.hasError = false;

                var initialize = function () {
                    var gridData = '';
                    $scope.pageDetails = {};
                    if ($scope.taskSummaryData.AAXD_duplicateSearchGrid) {
                        gridData = $scope.taskSummaryData.AAXD_duplicateSearchGrid.fieldValue;
                    }
                    $scope.pageDetails.resultData = gridData && gridData.trim() !== '' ? JSON.parse(gridData) : [];
                };
                initialize();
            }
        ]);
})();