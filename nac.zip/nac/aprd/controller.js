(function () {
    'use strict';

    function aprdController($scope, $log, $state, appConstantsService, $uibModal, $confirm, landingDetails, $stateParams) {
        // capture error fields and update navigation json
        var navItem = landingDetails.getNavItem('aprd');
        $scope.$watch('aprdForm.$valid', function (isValid) {
            navItem.hasError = !isValid;
        });

        $scope.Remove = function (index) {
            $confirm({
                    text: 'Are you sure you want to delete?',
                    title: 'Delete Requirement',
                    ok: 'Yes',
                    cancel: 'No'
                })
                .then(function () {
                    if ($scope.pageDetails.aprdRequirements[index].sequenceNo !== '') {
                        $scope.pageDetails.aprdRequirements[index].action = 'D';
                    }
                    else {
                        $scope.pageDetails.aprdRequirements.splice(index, 1);
                    }
                    $scope.updateRequirements();
                });
        };
        $scope.addReq = function (index) {
            $scope.aprdRequirementscopy = angular.copy($scope.pageDetails.aprdRequirements);
            if (!angular.isDefined(index)) {
                $scope.aprdRequirementscopy.push($scope.pageDetails.newReqGridRow);
                index = $scope.aprdRequirementscopy.length - 1;
            }
            var modalInstance = $uibModal.open({
                templateUrl: 'scripts/directives/nac/aprd/addNewReqModal.html',
                controller: 'ModalCustomReqCtrl',
                windowClass: 'case-modal-window',
                resolve: {
                    items: function () {
                        return angular.copy($scope.aprdRequirementscopy);
                    },
                    itemIndex: function () {
                        return index;
                    }
                }
            });
            modalInstance.result.then(function (resultArray) {
                $scope.pageDetails.aprdRequirements = resultArray;
                $scope.updateRequirements();
            });
        };
        $scope.updateRequirement = function (index) {
            if ($scope.pageDetails.aprdRequirements[index].sequenceNo !== '') {
                $scope.pageDetails.aprdRequirements[index].action = 'U';
            }
            $scope.updateRequirements();
        };

        $scope.updateRequirements = function () {

            var fieldValue = JSON.stringify($scope.pageDetails.aprdRequirements);

            fieldValue = fieldValue.replace('"isNew":true,', '').replace(',"isNew":true', '');
            $scope.taskSummaryData.APRD_requirementsGrid.fieldValue = fieldValue;

        };

        $scope.open = function () {
            var modalInstance = $uibModal.open({
                templateUrl: 'scripts/directives/nac/aprd/masterReqModal.html',
                controller: 'masterReqModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.pageDetails.aprdRequirements;
                    }
                }
            });
            modalInstance.result.then(function (selected) {
                if (selected.length) {
                    $scope.pageDetails.aprdRequirements = $scope.pageDetails.aprdRequirements.concat(selected);
                    $scope.updateRequirements();
                }

            });
        };

        var inilialize = function () {
            $scope.flag = false;
            $scope.pageDetails = {};
            $scope.pageDetails.newReqGridRow = {
                'sequenceNo': null,
                'status': '',
                'description': '',
                'comments': '',
                'orderBy': '',
                'receiveBy': '',
                'maintainBy': '',
                'action': 'N'
            };
            $scope.pageDetails.process =  $stateParams.process;
            var reqs = $scope.taskSummaryData.APRD_requirementsGrid.fieldValue;
            $scope.pageDetails.aprdRequirements = reqs && reqs !== '' ? JSON.parse(reqs) : [];

            if ($scope.taskSummaryData.APRD_errorGrid) {
                var errorData = $scope.taskSummaryData.APRD_errorGrid.fieldValue;
                $scope.pageDetails.aprdErrorGrid = errorData && errorData !== '' ? JSON.parse(errorData) : [];
            }
            $scope.pageDetails.requirements = appConstantsService.getRequirements();
            $scope.pageDetails.aprdReqStatusDropdown = appConstantsService.getDropdowns().aprdReqStatus;
        };

        inilialize();
    }

    function masterReqModalCtrl($scope, $uibModalInstance, items, $log, appConstantsService, taskService, toastr) {
        $scope.ok = function () {
            var selectedItems = [],
                newRequirement;
            for (var i = 0; i < $scope.pageDetails.requirements.length; i++) {
                if ($scope.pageDetails.requirements[i].selected && !$scope.pageDetails.requirements[i].disabled) {
                    newRequirement = angular.copy($scope.aprdGridRow);
                    newRequirement.description = $scope.pageDetails.requirements[i].description;
                    newRequirement.comments = $scope.pageDetails.requirements[i].comments;
                    selectedItems.push(newRequirement);
                }
            }
            $uibModalInstance.close(selectedItems);
        };

        $scope.toggle = function () {
            $scope.state = !$scope.state;
        };

        $scope.save = function () {
            var finalReqobj = [];
            var newObj = {
                description: $scope.pageDetails.description,
                comments: $scope.pageDetails.comments
            };
            finalReqobj = appConstantsService.getRequirements();
            var flag = false;

            for (var i = 0; i < finalReqobj.length; i++) {
                if (finalReqobj[i].description.toUpperCase() === newObj.description.toUpperCase()) {
                    toastr.error('Requirement with same description already exists', {
                        timeOut: 4000
                    });
                    flag = false;
                    break;
                }
                else {
                    delete finalReqobj[i].selected;
                    flag = true;
                }

            }
            if (flag === true) {
                finalReqobj.push(newObj);
                var masterkey = 'requirements';
                taskService.addRequirement(finalReqobj, masterkey).then(function (response) {
                    if (response.data.message === 'success') {
                        $scope.pageDetails.requirements.push(newObj);
                        appConstantsService.setRequirements(finalReqobj);
                        toastr.success('New Requirement added Successfully', {
                            timeOut: 4000
                        });
                        $scope.pageDetails.description = '';
                        $scope.pageDetails.comments = '';
                        $scope.state = false;
                    }
                });
            }
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss();
        };

        $scope.clear = function () {
            $scope.pageDetails.description = '';
            $scope.pageDetails.comments = '';
            $scope.state = false;
        };

        var initialize = function () {
            var masterList = appConstantsService.getRequirements();
            $scope.pageDetails = {};
            for (var i = 0; i < items.length; i++) {
                if (items[i].action !== 'D') {
                    for (var j = 0; j < masterList.length; j++) {
                        if (items[i].description === masterList[j].description) {
                            masterList[j].disabled = true;
                            masterList[j].selected = true;
                        }
                    }
                }
            }
            $scope.pageDetails.requirements = masterList;
            //Grid Row
            $scope.aprdGridRow = {
                sequenceNo: null,
                status: '',
                description: '',
                comments: '',
                orderBy: '',
                receiveBy: '',
                maintainBy: '',
                action: 'N'
            };
        };
        initialize();
    }

    function ModalCustomReqCtrl($scope, $uibModalInstance, items, $log, itemIndex, appConstantsService) {
        $scope.itemIndex = itemIndex;
        $scope.items = items;
        $scope.pageDetails = {};
        $scope.pageDetails.aprdReqStatusDropdown = appConstantsService.getDropdowns().aprdReqStatus;
        $scope.ok = function () {
            $uibModalInstance.close(items);
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss();
        };
        //To Set the initial Error
        $scope.setForm = function (form) {
            if ($scope.items[itemIndex].action === 'N') {
                form.$$element.attr('no-init-validate', true);
            }
            else {
                form.$$element.removeAttr('no-init-validate');
            }
        };
    }

    angular.module('wrapper.nac').directive('aprd', function () {
            return {
                restrict: 'E',
                scope: {
                    taskSummaryData: '=taskSummaryData'
                },
                controller: 'aprdController',
                link: function (scope, elem, attrs) {},
                templateUrl: 'scripts/directives/nac/aprd/aprd.html'
            };
        })
        .controller('aprdController', aprdController)
        .controller('masterReqModalCtrl', masterReqModalCtrl)
        .controller('ModalCustomReqCtrl', ModalCustomReqCtrl);

    aprdController.$inject = ['$scope', '$log', '$state', 'appConstantsService', '$uibModal', '$confirm', 'landingDetails', '$stateParams'];
    masterReqModalCtrl.$inject = ['$scope', '$uibModalInstance', 'items', '$log', 'appConstantsService', 'taskService', 'toastr'];
    ModalCustomReqCtrl.$inject = ['$scope', '$uibModalInstance', 'items', '$log', 'itemIndex', 'appConstantsService'];
})();