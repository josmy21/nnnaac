'use strict';
describe('Directive: aprd', function () {
    var $compile;
    var $scope;
    var $httpBackend, $q, $http, testdata, appConstantsService;
    beforeEach(module('wrapper.nac'));
    beforeEach(module('wrapper.Templates'));
    beforeEach(module('ui.router'));
    beforeEach(module('wrapper.constantsFactory'));
    beforeEach(module('wrapper.services'));
    beforeEach(module('wrapper.environment'));
    beforeEach(module('applicationContextRoot'));
    beforeEach(module('urlUtilities.service'));
    beforeEach(module('applicationContext'));
    beforeEach(module('sfgEnvironment'));
    beforeEach(module('wrapper.model'));

    beforeEach(function () {
        module(function ($provide) {
            $provide.value('$uibModal', {});
            $provide.value('$confirm', {});

            $provide.value('sfgEnvironmentService', {});
            $provide.value('$analytics', {});
            $provide.value('sfgApplication', {
                isMockDataMode: true,
                isAuthenticated: true
            });

            $provide.value('sfgErrorModal', {});

            $provide.value('sfgApplicationLoggingService', {
                debug: function () {}
            });

            $provide.value('sfgEnvironmentService', {
                read: function () {
                    return true;
                }
            });
            $provide.value('appConstantsService', {
                getDropdowns: function () {
                    return [];
                },
                loadConstants: function () {
                    return [];
                },
                getRequirements: function () {
                    return [];
                }
            });
        });
    });

    beforeEach(inject(function (_$compile_, _$rootScope_, _$httpBackend_, _$http_, _$q_, _appConstantsService_, taskService) {

        $compile = _$compile_;
        $scope = _$rootScope_;
        $httpBackend = _$httpBackend_;
        $http = _$http_;
        $q = _$q_;
        appConstantsService = _appConstantsService_;

        $httpBackend.expectGET('data/appConstants.json').respond({});
        $httpBackend.expectGET('data/countries_Cyber.json').respond({});
        $httpBackend.expectGET('data/states.json').respond({});
        $httpBackend.expectGET('/getAllMasterList').respond({});

    }));

    var compiledElement = function (val) {

        var el;
        testdata = readJSON('mock-data/policyDetails_NAC.json');

        var taskSummaryData = {};
        angular.forEach(testdata, function (item) {
            taskSummaryData[item.treePath] = item;
        });
        taskSummaryData.formsStatus = {
            'acwdForm': {
                'pageName': 'ACWD - TIA Money',

                'valid': null
            },
            'atrnForm': {
                'pageName': 'ATRN - Policy Details',

                'valid': null,
                'tabs': {}
            },
            'aprdForm': {
                'pageName': 'APRD - Requirements',

                'valid': null
            }
        };
        $scope.taskSummaryData = taskSummaryData;
        el = angular.element('<aprd task-summary-data="taskSummaryData"></aprd>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    describe('getting isolate scope', function () {
        it('binding isolate scope', function () {
            var el = compiledElement();
            expect(el.isolateScope().$id).not.toEqual($scope.$id);

        });

    });
    describe('getting textfields', function () {
        it('binding isolate scope', function () {
            var attrName = angular.element(compiledElement()[0].querySelector('table'))[0];
            expect(attrName.rows[1].cells.length).toBe(7);

        });
    });

});